let displayValue = '';

function appendNumber(num) {
  displayValue += num;
  document.getElementById('display').value = displayValue;
}

function appendOperator(operator) {
  if (displayValue !== '') {
    displayValue += operator;
    document.getElementById('display').value = displayValue;
  }
}

function clearDisplay() {
  displayValue = '';
  document.getElementById('display').value = '';
}

function calculate() {
  try {
    const result = eval(displayValue);
    document.getElementById('display').value = result;
    displayValue = '';
  } catch (error) {
    document.getElementById('display').value = 'Error';
  }
}
